'''
Created on Mar 28, 2013

@author: timmahrt

DON'T CHANGE UNLESS YOU KNOW WHAT YOU'RE DOING
-- please use this page as a reference to know where to put things
'''

from os.path import join

# EDITING THESE ONLY MODIFIES METADATA AND WILL NOT IMPAIR LMEDS
softwareName = "LMEDS: Language Markup and Experimental Design Software"
rootURL = "http://tmahrt.nfshost.com/rptTest"


# EDITING THE BELOW MIGHT PREVENT LMEDS FROM FUNCTIONING

rootDir = "/home/gail/Senior_Project/flask_example/app/"

# 
htmlDir = join(rootDir, "html")
htmlSnippetsDir = join(htmlDir, "snippets")
instructDir = join(htmlDir, "instructions")




