# -*- coding: utf-8 -*-
'''
Created on Mar 28, 2013

@author: timmahrt

Common HTML snippets
'''

import os
import Cookie

from functools import partial

from lmeds import loader

choice = """<input type="radio" name="radio">"""
img = """<img src="data/%s">"""
txtBox = """<input type="text" name="%s" value=""/>"""
radioButton = """<input type="radio" name="radio" value="%s">"""

pg2HTML = """
%%(explain)s<br /><br />
%(choiceA)s %%(consent)s\n
<br /><br />\n
%(choiceB)s %%(dissent)s
""" % {"choiceA":radioButton % "consent",
       "choiceB":radioButton % "dissent"
       }


formTemplate = """
<div id='audio_hook'></div>
<form class="submit" name="languageSurvey" method="POST">
%(html)s

<input TYPE="hidden" name="page" value="%(page)s"> 
<input TYPE="hidden" name="pageNumber" value="%(pageNumber)d"> 
<input TYPE="hidden" name="cookieTracker" value="%(cookieTracker)s"> 
<input TYPE="hidden" name="user_name" value="%(user_name)s"> 
<input TYPE="hidden" name="num_items" value="%(num_items)d">
<input TYPE="hidden" name="task_duration" id="task_duration" value="0">
%(audio_play_tracking_html)s
<br /><br />
%(submit_button_slot)s
</form>
"""

# This is more or less a HACK 
# -- we needed to hide the submit button, but only in a single situation
# -- (it reappears after someone clicks another button--handled via javascript)
formTemplate2 = """
<div id='audio_hook'></div>
<form class="submit" name="languageSurvey" method="POST">
%(html)s

<div id="HiddenForm" style="DISPLAY: none">
<input TYPE="hidden" name="page" value="%(page)s"> 
<input TYPE="hidden" name="pageNumber" value="%(pageNumber)d"> 
<input TYPE="hidden" name="cookieTracker" value="%(cookieTracker)s"> 
<input TYPE="hidden" name="user_name" value="%(user_name)s"> 
<input TYPE="hidden" name="num_items" value="%(num_items)d">
<input TYPE="hidden" name="task_duration" id="task_duration" value="0">
%(audio_play_tracking_html)s
<br /><br />
%(submit_button_slot)s
</div>
</form>
"""

submitButtonHTML = """<input name="submitButton" type="button" value="%s">"""


def getWidgetSubmit(widgetName):
    '''Associates all widgets with a provided name (%s) with the submit function'''
    widgetSubmit = """ 
      var radios = document.getElementsByName("%s");
      for (var i = [0]; i < radios.length; i++) {
        radios[i].onclick=processSubmit;
    }""" % widgetName    
    return widgetSubmit


def getTimeoutSubmit(timeS):
    '''Associates a timeout with the submit function'''
    timeoutSubmit = "setTimeout(processSubmit, %d);" % int(float(timeS) * 1000)
    return timeoutSubmit


def constructSubmitAssociation(tupleList):
    returnStr = ""
    assocDict = {'widget': getWidgetSubmit,
                 'timeout': getTimeoutSubmit}
    for task, arg in tupleList:
        returnStr += assocDict[task](arg) + "\n"
    
    return returnStr


# Associates a submit button with 
taskDurationCode = """
<script type="text/javascript">

var start = new Date().getTime();

window.onload=function() {

%s


}

function calcDuration() {
    var time = new Date().getTime() - start;

    var seconds = Math.floor(time / 100) / 10;
    var minutes = Math.floor(seconds / 60);
    seconds = seconds - (minutes * 60);
    if(Math.round(seconds) == seconds) { 
        seconds += '.0'; 
    }
    var param1 = minutes.toString();
    var param2 = Number(seconds).toFixed(1);
    document.getElementById("task_duration").value = param1 + ":" + param2;
}
</script>
"""

audioPlayTrackingTemplate = '<input TYPE="hidden" name="audioFilePlays%(id)d" id="audioFilePlays%(id)d" value="0" />\n'


def createChoice(textList, i, checkboxFlag=False):
    
    widgetTemplate = """<input type="radio" name="%s" id="%s" value="%s">"""
    if checkboxFlag:
        widgetTemplate = """<input type="checkbox" name="%s" id="%s" value="%s">"""
        
    choiceList = []
    for text in textList:
        newRadioButton = widgetTemplate % (str(i), str(i), text)
        choiceList.append("%s %s" % (text, newRadioButton))
    
    txtSeparator = "&nbsp;" * 4
    
    return "%s" %  txtSeparator.join(choiceList), i + 1


def createChoicebox(textList, i):
    
    widgetTemplate = """<option value="%s">%s</option>"""
    
#     textList = ["",] + textList # Default value is blank
    
    choiceList = []
    for j, text in enumerate(textList):
        newChoice = widgetTemplate % (str(j), text)
        choiceList.append(newChoice)
        
    returnTxt = """<select name="%s" id="%s">%%s</select>""" % (str(i), str(i))
    returnTxt %= "\n".join(choiceList)
    
    return returnTxt, i + 1


def createTextbox(i):
    tmpTxtBox = """<input type="text" name="%s" id="%s" value=""/>"""
    return tmpTxtBox % (str(i), str(i)), i + 1


def createTextfield(i, argList):
    width = argList[0] # Units in number of characters
    numRows = argList[1]
    return """<textarea name="%s" id="%s" rows="%s" cols="%s"></textarea>""" % (str(i), str(i), numRows, width), i + 1

    
def createWidget(widgetType, argList, i):

    elementDictionary = {"Choice":createChoice,
                         "Item_List":partial(createChoice, checkboxFlag=True),
                         "Choicebox":createChoicebox,
                         }
    
    if widgetType == "Textbox":
        widgetHTML, i = createTextbox(i)
    elif widgetType == "Multiline_Textbox":
        widgetHTML, i = createTextfield(i, argList)
    else:
        widgetHTML, i = elementDictionary[widgetType](argList, i)
        
    return widgetHTML, i



        
        
def getLoadingNotification():
    loadingText = "- %s - " % loader.getText("loading_progress")
    progressBarTemplate = """
    <div id="loading_status_indicator" class="centered_splash">
    <div class="centered_splash_inner">
    %s
    <dl class="progress">
        <dt>Completed:</dt>
        <dd id="loading_percent_done" class="done" style="width:0%%"><a href="/"></a></dd>
    
        <dt >Left:</dt>
        <dd id="loading_percent_left" class="left" style="width:100%%"><a href="/"></a></dd>
    </dl>

    </div>
    </div>
    """
    # A button users can use to reload their audio if 
    #<input type="button" id="reload_button" value="Reload" onClick="reload_audio()">
    # htmlMsg: If you suspect the audio has failed to load (e.g. due to a poor internet connection) please press this button to attempt to reload the audio.

    return progressBarTemplate % loadingText
    

def getProgressBar():
    progressBarText = "- %s - <br />" % loader.getText("progress")
    
    progressBarTemplate = progressBarText + """
    <dl class="progress">
        <dt>Completed:</dt>
        <dd class="done" style="width:%(percentComplete)s%%%%"><a href="/"></a></dd>
    
        <dt >Left:</dt>
        <dd class="left" style="width:%(percentUnfinished)s%%%%"><a href="/"></a></dd>
    </dl>
    """
    
    return progressBarTemplate


def validateAndUpdateCookie(pageNum):
    '''
    Tracks the progress of pages.  If a page is reloaded, terminate execution.
    
    In order to implement this, the pageNum must always increase by an
    arbitrary amount with each new page.  If the pageNum is less than or equal
    to what it was before, this indicates the reloading of an older page.
    
    Terminating the test prevents users from hitting /back/ and then /forward/
    to wipe page-variables like num-of-times-audio-file-played.
    '''
    oldPageNum = -1
    try:
        cookie = Cookie.SimpleCookie(os.environ["HTTP_COOKIE"])
        oldPageNum = int(cookie["lastPage"].value)
    except(Cookie.CookieError, KeyError):
        if pageNum != 0:
            print "\n\nERROR: Page number is %d according to index.cgi but no cookies found" % pageNum
            exit(0)
    else:
        if pageNum <= oldPageNum and pageNum != 0:
            print "\n\nERROR: Back button or refresh detected", pageNum, oldPageNum
            exit(0)
    
#    # Set expiration five minutes from now
#    expiration = datetime.datetime.now() + datetime.timedelta(minutes=5)
    cookie = Cookie.SimpleCookie()
    cookie["lastPage"] = pageNum
    
    return cookie, oldPageNum, pageNum


def printCGIHeader(pageNum, disableRefreshFlag):
    '''
    This header must get printed before the website will render new text as html
    
    A double newline '\n\n' indicates the end of the header.
    '''
    print 'Content-Type: text/html'
    
    if disableRefreshFlag:
        print "Pragma-directive: no-cache"
        print "Cache-directive: no-cache"
        print "Cache-Control: no-cache, no-store, must-revalidate"
        print "Pragma: no-cache"
        print "Expires: 0"
        cookieStr= validateAndUpdateCookie(pageNum)[0]
        print cookieStr
    print "\n\n"


def checkForAudioTag():
    txt = '''
    <script type="text/javascript">
    
function isSupportedBrowser() {

if(!!document.createElement('audio').canPlayType == false) {
    document.getElementById("submit").disabled = true;
    document.getElementById("unsupported_warning").style.display='block';
}

    }
    </script>
    '''

    return txt


def makeNoWrap(htmlTxt):
    return '<div id="noTextWrapArea">\n\n%s\n\n</div>' % htmlTxt


def makeWrap(htmlTxt):
    return '<div id="textWrapArea">\n\n%s\n\n</div>' % htmlTxt


processSubmitHTML = """
<script  type="text/javascript">
function processSubmit()
{
calcDuration();
var returnValue = true;

%s


if (returnValue == true) {
document.languageSurvey.submit()
}

return returnValue;    
}
</script>
"""



if __name__ == "__main__":
    loader.initTextDict("../english.txt")

